﻿/*
이름: 이시온
날짜: 2024.11.27

## **과제 1. 숫자 야구 제작**

※ 배열 없이도 제작 가능합니다

- 컴퓨터는 임의의 세자리 숫자를 가지고 있음. 플레이어가 컴퓨터를 위한 중복되지 않는 임의의 세자리를 입력해주면 됩니다. (컴퓨터가 지 혼자 알고 있을 숫자 102~987)
- 유저는 세자리 수를 입력하되 동일한 자리의 숫자가 있을 경우, 유저에게 다시 입력하라고 반복 시킴.
- 컴퓨터가 정한 수와, 유저가 입력한 숫자를 비교해서 만약 자릿수가 일치한 것이 있다면 스트라이크 수가 늘어남. 예를 들어, 컴퓨터의 수는 142고, 유저 입력은 172면 2스트라이크.
- 컴퓨터의 숫자와 유저가 입력한 숫자를 비교해서 숫자가 존재하긴 하나, 자릿수가 다를 경우, 볼 갯수가 증가. 예를 들어 172가 컴퓨터 숫자고, 127을 유저가 입력했다면 1스트라이크 2볼.
- 유저가 입력한 값 중 어느 하나도 컴퓨터의 숫자와 비교해서 같은 것이 없는 상황엔, 즉 볼과 스트라이크가 모두 없는 상황엔 ‘n스트라이크n볼’ 대신 ‘아웃’ 출력
- 3스트라이크 모두 나올때까지 유저는 계속 입력하게 되며, 유저의 입력 한번 당, 이닝이 하나씩 증가함
- 11이닝이 되기 전까지 3스트라이크를 내면 유저의 승, 11이닝이 될 때까지 3스트라이크가 나오지 않았다면 컴퓨터의 승리
*/

using System;

namespace Homework1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const bool debugMode = true;

            Random random = new();

            // 컴퓨터가 생성한 무작위 숫자 3개를 담을 변수.
            int number1, number2, number3;
            /*
            // *첫 번째 방법*

            // 세 숫자가 겹치지 않을 때 까지 반복.
            while (true)
            {
                // 무작위 숫자 생성(102~987).
                int randomNumber = random.Next(102, 987);

                // 100의 자리 수는 첫 번째 숫자.
                // 10의 자리 수는 두 번째 숫자.
                // 1의 자리 수는 세 번째 숫자.

                // 100의 자리 숫자를 10으로 나눈 나머지는 1의 자리수.
                number3 = randomNumber % 10;

                // 1의 자리를 날림.
                randomNumber /= 10;

                // 10의 자리 숫자를 10으로 나눈 나머지는 1의 자리수.
                number2 = randomNumber % 10;

                // 만약 두 번째 숫자와 세 번째 숫자가 겹친다면,
                if (number2 == number3)
                {
                    // 반복문 다시 시작.
                    continue;
                }
                
                // 1의 자리를 날림.
                randomNumber /= 10;

                number1 = randomNumber;

                // 만약 첫 번째 숫자가 나머지 숫자와 겹치지 않는다면,
                if (number1 != number2 || number1 == number3)
                {
                    // 무한 반복문 탈출.
                    break;
                }
            }
            */
            // *두 번째 방법*

            // 첫 번째 무작위 숫자 생성(0~9).
            number1 = random.Next(0, 9);

            // 두 번째 숫자가 첫 번째 숫자와 겹치지 않을 때 까지 반복.
            while (true)
            {
                // 두 번째 무작위 숫자 생성(0~9).
                number2 = random.Next(0, 9);

                // 만약 생성된 숫자가 첫 번째 숫자와 겹치지 않으면,
                if (number2 != number1)
                {
                    // 무한 반복문 탈출.
                    break;
                }
            }

            // 세 번째 숫자가 나머지 숫자와 겹치지 않을 때 까지 반복.
            while (true)
            {
                // 세 번째 무작위 숫자 생성(0~9).
                number3 = random.Next(0, 9);

                // 만약 생성된 숫자가 나머지 숫자와 겹치지 않으면,
                if (number3 != number1 && number3 != number2)
                {
                    // 무한 반복문 탈출.
                    break;
                }
            }

            Console.WriteLine("[숫자 야구 게임]");

            // (디버깅) 정답 확인
            if (debugMode == true)
            {
                Console.WriteLine();
                Console.WriteLine($"(디버깅) 정답: {number1}{number2}{number3}");
            }

            // 11회말 까지 진행. 11회말 초과시 게임 오버.
            for (int inning = 1; inning <= 11; ++inning)
            {
                // 스트라이크, 볼, 아웃의 횟수를 저장하는 변수.
                int strikeCount = 0;
                int ballCount = 0;
                int outCount = 0;

                Console.WriteLine();
                Console.WriteLine("-------------------------");
                Console.WriteLine();
                Console.WriteLine($"[{inning}회말]");
                Console.WriteLine();
                Console.Write("정답 입력(102~987): ");

                // 정답 입력(102~987)
                int.TryParse(Console.ReadLine(), out int guessNumbers);

                Console.WriteLine();

                // 100의 자리 수는 첫 번째 숫자,
                // 10의 자리 수는 두 번째 숫자,
                // 1의 자리 수는 세 번째 숫자.

                // 100의 자리 숫자를 10으로 나눈 나머지는 1의 자리수.
                int guessNumber3 = guessNumbers % 10;

                // 1의 자리를 날림.
                guessNumbers /= 10;

                // 10의 자리 숫자를 10으로 나눈 나머지는 1의 자리수.
                int guessNumber2 = guessNumbers % 10;

                // 1의 자리를 날림.
                guessNumbers /= 10;

                // 100의 자리 숫자를 10으로 나눈 나머지는 1의 자리수.
                int guessNumber1 = guessNumbers;

                // 만약 입력한 첫 번째 수가 컴퓨터가 생성한 첫 번째 숫자와 일치한다면,
                if (guessNumber1 == number1)
                {
                    // 스트라이크 증가.
                    ++strikeCount;
                }

                // 만약 입력한 첫 번째 수가 컴퓨터가 생성한 나머지 숫자와 일치한다면,
                else if (guessNumber1 == number2 || guessNumber1 == number3)
                {
                    // 볼 증가.
                    ++ballCount;
                }

                // 만약 입력한 세 번째 수가 컴퓨터가 생성한 모든 숫자와 일치하지 않는다면,
                else
                {
                    // 아웃 증가.
                    ++outCount;
                }

                // 만약 입력한 두 번째 수가 컴퓨터가 생성한 두 번째 숫자와 일치한다면,
                if (guessNumber2 == number2)
                {
                    // 스트라이크 증가.
                    ++strikeCount;
                }

                // 만약 입력한 두 번째 수가 컴퓨터가 생성한 나머지 숫자와 일치한다면,
                else if (guessNumber2 == number1 || guessNumber2 == number3)
                {
                    // 볼 증가.
                    ++ballCount;
                }

                // 만약 입력한 세 번째 수가 컴퓨터가 생성한 모든 숫자와 일치하지 않는다면,
                else
                {
                    // 아웃 증가.
                    ++outCount;
                }

                // 만약 입력한 세 번째 수가 컴퓨터가 생성한 세 번째 숫자와 일치한다면,
                if (guessNumber3 == number3)
                {
                    // 스트라이크 증가.
                    ++strikeCount;
                }

                // 만약 입력한 세 번째 수가 컴퓨터가 생성한 나머지 숫자와 일치한다면,
                else if (guessNumber3 == number1 || guessNumber3 == number2)
                {
                    // 볼 증가.
                    ++ballCount;
                }

                // 만약 입력한 세 번째 수가 컴퓨터가 생성한 모든 숫자와 일치하지 않는다면,
                else
                {
                    // 아웃 증가.
                    ++outCount;
                }

                // 만약 아웃 횟수가 3이라면,
                if (outCount == 3)
                {
                    // 아웃만 출력 후,
                    Console.WriteLine($"[Out]");

                    // 회말 종료.
                    continue;
                }

                // 만약 스크라이크 횟수가 0보다 클 때,
                if (strikeCount > 0)
                {
                    // 스크라이크 횟수가 3이라면,
                    if (strikeCount == 3)
                    {
                        // 승리 출력 후,
                        Console.WriteLine("-------------------------");
                        Console.WriteLine();
                        Console.Write("승리하였습니다.");
                        Console.ReadKey(true);

                        // 게임 종료.
                        return;
                    }

                    // 아니라면 스크라이크 횟수 출력.
                    Console.Write($"[{strikeCount} Strike] ");
                }

                // 만약 볼 횟수가 0보다 크다면,
                if (ballCount > 0)
                {
                    // 볼 횟수 출력.
                    Console.Write($"[{ballCount} Ball]");
                }

                Console.WriteLine();

                // 회말 종료.
            }

            // 패배 출력 후,
            Console.WriteLine();
            Console.WriteLine("-------------------------");
            Console.WriteLine();
            Console.Write("패배하였습니다.");
            Console.ReadKey(true);

            // 게임 종료.
        }
    }
}