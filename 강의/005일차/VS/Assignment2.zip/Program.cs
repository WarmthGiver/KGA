﻿/*
이름: 이시온
날짜: 2024.11.26

### 심화 과제 2. 입력을 통한 다이아몬드 출력 기능 구현

- 출력할 다이아몬드 형태를 사용자로부터 입력 받은 후, 만약 짝수일경우 홀수를 다시 입력하라고 유저에게 무한 반복으로 요구한다.
- 홀수가 입력되었을 경우, 다이아몬드 중간 부분이 유저의 입력과 같은 다이아몬드를 출력하는 프로그램 제작.
 */

using System;

namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int size;

            while (true)
            {
                Console.Write("다이아몬드 크기 입력 (홀수): ");

                int.TryParse(Console.ReadLine(), out size);

                if (size % 2 == 0)
                {
                    Console.Clear();

                    Console.WriteLine("홀수만 입력해주세요.\n");

                    continue;
                }

                break;
            }

            Console.Clear();

            int halfSize = size / 2;

            for (int i = 0; i <= halfSize; ++i)
            {
                // halfSize - i 만큼 ' ' 출력
                for (int j = i; j < halfSize; ++j)
                {
                    Console.Write(' ');
                }
                /*
                int blankCount = halfSize - i;

                for (int j = 0; j < blankCount; ++j)
                {
                    Console.Write(' ');
                }
                */

                //1 + i * 2 만큼 '*' 출력
                for (int j = i * 2; j >= 0; --j)
                {
                    Console.Write('*');
                }
                /*
                int starCount = 1 + i * 2;

                for (int j = 0; j < starCount; ++j)
                {
                    Console.Write('*');
                }
                */

                Console.WriteLine();
            }

            // halfSize - 1부터 역출력
            for (int i = halfSize - 1; i >= 0; --i)
            {
                for (int j = i; j < halfSize; ++j)
                {
                    Console.Write(' ');
                }

                for (int j = i * 2; j >= 0; --j)
                {
                    Console.Write('*');
                }

                Console.WriteLine();
            }
        }
    }
}