﻿namespace ZL.CS.FW
{
    public sealed class BackgroundDrawer : Drawer<Background>
    {

    }
}