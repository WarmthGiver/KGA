﻿namespace ZL.CS.FW
{
    public sealed class TextDrawer : Drawer<Text>
    {

    }
}