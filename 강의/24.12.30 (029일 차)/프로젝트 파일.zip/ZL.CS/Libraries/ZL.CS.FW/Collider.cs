﻿namespace ZL.CS.FW
{
    public sealed class Collider : Component
    {

    }
}