﻿namespace ZL.CS.FW
{
    public sealed class ForegroundDrawer : Drawer<Foreground>
    {

    }
}