﻿using System.Numerics;

namespace ZL.CS.FW
{
    public interface IDrawable
    {
        public void Draw(Vector3 position);
    }
}