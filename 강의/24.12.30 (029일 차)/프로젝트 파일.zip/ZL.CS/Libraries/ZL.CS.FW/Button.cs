﻿namespace ZL.CS.FW
{
    public sealed class Button : Selectable
    {

    }
}